import json
import boto3

s3 = boto3.client('s3')
sts = boto3.client('sts')

def lambda_handler(event, context):
    AWS_ACCOUNT_ID = sts.get_caller_identity()["Account"]
    data_to_check = event["data"]
    all_objects = s3.list_objects_v2(Bucket = "aws-sc-data-"+AWS_ACCOUNT_ID)["Contents"]
    
    data_ready = []
    for object in all_objects:
        data_ready.append(object["Key"])
    
    for data_item in data_to_check:
        if data_item["S3url"] in data_ready:
            data_item["ready"] = True
            
    print(data_to_check)
        
    return {
        'statusCode': 200,
        'body': json.dumps({"checked_data": data_to_check})
    }
